payload = {
    'time_zone': TIME_ZONE,
    'include[]': INCLUDE,
    'user_ids[]': USER_IDS,
    'escalation_policy_ids[]': ESCALATION_POLICY_IDS,
    'schedule_ids[]': SCHEDULE_IDS,
    'since': SINCE,
    'until': UNTIL,
    'earliest': EARLIEST
}


headers = {
    'Accept': 'application/vnd.pagerduty+json;version=2',
    'Authorization': 'Token token={token}'.format(token=api_key)
}

INCLUDE = []


def get_service():
    url = 'https://api.pagerduty.com/services/{id}'.format(id=ID)
    headers = {
        'Accept': 'application/vnd.pagerduty+json;version=2',
        'Authorization': 'Token token={token}'.format(token=api_key)
    }
    payload = {
        'include[]': INCLUDE
    }
    r = requests.get(url, headers=headers, params=payload)
    print('Status Code: {code}'.format(code=r.status_code))
    print(r.json())

if __name__ == '__main__':
    get_service()


url = 'https://api.pagerduty.com/oncalls'
headers = {
    'Accept': 'application/vnd.pagerduty+json;version=2',
    'Authorization': 'Token token={token}'.format(token=api_key)
}
payload = {
    'time_zone': TIME_ZONE,
    'include[]': INCLUDE,
    'user_ids[]': USER_IDS,
    'escalation_policy_ids[]': ESCALATION_POLICY_IDS,
    'schedule_ids[]': SCHEDULE_IDS,
    'since': SINCE,
    'until': UNTIL,
    'earliest': EARLIEST
}
r = requests.get(url, headers=headers, params=payload)
print('Status Code: {code}'.format(code=r.status_code))
print(r.json())



QUERY = ''
USER_IDS = []
TEAM_IDS = []
INCLUDE = []
SORT_BY = 'name'



url = 'https://api.pagerduty.com/escalation_policies'
headers = {
    'Accept': 'application/vnd.pagerduty+json;version=2',
    'Authorization': 'Token token={token}'.format(token=API_KEY)
}
payload = {
    'query': QUERY,
    'user_ids[]': USER_IDS,
    'team_ids[]': TEAM_IDS,
    'include[]': INCLUDE,
    'sort_by': SORT_BY
}
r = requests.get(url, headers=headers, params=payload)
print('Status Code: {code}'.format(code=r.status_code))
print(r.json())



# Service

ID = "PG6L9D7" #PG6L9D7
INCLUDE = []

url = 'https://api.pagerduty.com/services/{id}'.format(id=ID)
headers = {
    'Accept': 'application/vnd.pagerduty+json;version=2',
    'Authorization': 'Token token={token}'.format(token=api_key)
}
payload = {
    'include[]': INCLUDE
}
r = requests.get(url, headers=headers, params=payload)
print('Status Code: {code}'.format(code=r.status_code))
print(r.json())


---------
                                   'id': 'PKPM616',
                                   'self': 'https://api.pagerduty.com/escalation_policies/PKPM616',
                                   'summary': 'Team-2A',

---------
# Escalation ploicy

QUERY = ''
USER_IDS = []
TEAM_IDS = []
INCLUDE = []
SORT_BY = 'name'


url = 'https://api.pagerduty.com/escalation_policies'
headers = {
    'Accept': 'application/vnd.pagerduty+json;version=2',
    'Authorization': 'Token token={token}'.format(token=API_KEY)
}
payload = {
    'query': QUERY,
    'user_ids[]': USER_IDS,
    'team_ids[]': TEAM_IDS,
    'include[]': INCLUDE,
    'sort_by': SORT_BY
}
r = requests.get(url, headers=headers, params=payload)
print('Status Code: {code}'.format(code=r.status_code))
print(r.json())












pd_url = "https://automata.pagerduty.com/incidents/PY9RLSH"
pd_url = "https://automata.pagerduty.com/incidents/P6K21KT"
apiurl = pd_url.replace("automata", "api")
s_url = apiurl.split("/")
incident_id = s_url[4]
res = requests.get(apiurl, headers=headers)
data = res.json()
raw = data["incident"]["title"]
raw #is the title of alert
substring = "Build #"

try:
    raw.index(substring)
except ValueError:
    print("Not found")
else:
    print("Found")



build_name = ="SAMPLE"


data_slack = json.dumps({"text": str(build_name),
    "attachments": [
        {
            "color": "#32CD32",
            "text": "@here"
        },
        {
            "color": "#2f52a4",
            "text": "Success",
            "footer": "Slack API | created by Haad"
        },
    ]
})
slack_headers = {
    'Content-type': 'application/json',
}